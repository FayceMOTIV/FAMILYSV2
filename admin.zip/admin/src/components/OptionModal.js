import React, { useState, useEffect } from 'react';
import { Modal } from './Modal';
import { Button } from './Button';
import { X, Plus, Trash2, ChevronDown, ChevronRight, Settings, BookOpen } from 'lucide-react';
import axios from 'axios';

export const OptionModal = ({ isOpen, onClose, option, onSuccess }) => {
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    internal_comment: '',
    type: 'single',
    is_required: false,
    allow_repeat: false,
    max_choices: '',
    choices: [{ id: crypto.randomUUID(), name: '', price: 0, image_url: '', internal_comment: '', sub_options: [] }],
    display_order: 0
  });
  
  const [loading, setLoading] = useState(false);
  const [expandedChoices, setExpandedChoices] = useState({});
  const [toast, setToast] = useState(null);
  const [choiceLibrary, setChoiceLibrary] = useState([]);
  const [showLibraryPicker, setShowLibraryPicker] = useState(null); // { type: 'choice' | 'subChoice', choiceIndex, subOptionIndex }
  const [librarySearch, setLibrarySearch] = useState('');

  const API_URL = process.env.REACT_APP_BACKEND_URL || 'http://localhost:8000';

  // Charger la bibliothèque de choix
  useEffect(() => {
    if (isOpen) {
      loadChoiceLibrary();
    }
  }, [isOpen]);

  const loadChoiceLibrary = async () => {
    try {
      const response = await axios.get(`${API_URL}/api/v1/admin/choice-library`);
      setChoiceLibrary(response.data.choices || []);
    } catch (error) {
      console.error('Error loading choice library:', error);
    }
  };

  useEffect(() => {
    if (option) {
      setFormData({
        name: option.name || '',
        description: option.description || '',
        internal_comment: option.internal_comment || '',
        type: option.type || 'single',
        is_required: option.is_required || false,
        allow_repeat: option.allow_repeat || false,
        max_choices: option.max_choices || '',
        choices: option.choices?.length > 0 
          ? option.choices.map(c => ({
              id: c.id || crypto.randomUUID(),
              name: c.name || '',
              price: c.price || 0,
              image_url: c.image_url || '',
              internal_comment: c.internal_comment || '',
              sub_options: c.sub_options || []
            }))
          : [{ id: crypto.randomUUID(), name: '', price: 0, image_url: '', internal_comment: '', sub_options: [] }],
        display_order: option.display_order || 0
      });
    } else {
      setFormData({
        name: '',
        description: '',
        internal_comment: '',
        type: 'single',
        is_required: false,
        allow_repeat: false,
        max_choices: '',
        choices: [{ id: crypto.randomUUID(), name: '', price: 0, image_url: '', internal_comment: '', sub_options: [] }],
        display_order: 0
      });
    }
    setExpandedChoices({});
  }, [option, isOpen]);

  const showToast = (message, type = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3000);
  };

  // ================== GESTION DES CHOIX ==================
  const addChoice = () => {
    setFormData({
      ...formData,
      choices: [...formData.choices, { id: crypto.randomUUID(), name: '', price: 0, image_url: '', internal_comment: '', sub_options: [] }]
    });
  };

  // Ajouter un choix depuis la bibliothèque
  const addChoiceFromLibrary = (libraryChoice) => {
    setFormData({
      ...formData,
      choices: [...formData.choices, { 
        id: crypto.randomUUID(), 
        name: libraryChoice.name, 
        price: libraryChoice.default_price || 0, 
        image_url: libraryChoice.image_url || '', 
        internal_comment: '', 
        sub_options: [] 
      }]
    });
    setShowLibraryPicker(null);
    setLibrarySearch('');
  };

  // Ajouter un sous-choix depuis la bibliothèque
  const addSubChoiceFromLibrary = (libraryChoice, choiceIndex, subOptionIndex) => {
    const newChoices = [...formData.choices];
    newChoices[choiceIndex].sub_options[subOptionIndex].choices.push({
      id: crypto.randomUUID(),
      name: libraryChoice.name,
      price: libraryChoice.default_price || 0
    });
    setFormData({ ...formData, choices: newChoices });
    setShowLibraryPicker(null);
    setLibrarySearch('');
  };

  // Filtrer la bibliothèque
  const filteredLibrary = choiceLibrary.filter(c => 
    c.name.toLowerCase().includes(librarySearch.toLowerCase())
  );

  const removeChoice = (index) => {
    if (formData.choices.length > 1) {
      const newChoices = formData.choices.filter((_, i) => i !== index);
      setFormData({ ...formData, choices: newChoices });
    }
  };

  const updateChoice = (index, field, value) => {
    const newChoices = [...formData.choices];
    newChoices[index] = { ...newChoices[index], [field]: value };
    setFormData({ ...formData, choices: newChoices });
  };

  // ================== GESTION DES SOUS-OPTIONS ==================
  const toggleChoiceExpand = (choiceId) => {
    setExpandedChoices(prev => ({
      ...prev,
      [choiceId]: !prev[choiceId]
    }));
  };

  const addSubOption = (choiceIndex) => {
    const newChoices = [...formData.choices];
    if (!newChoices[choiceIndex].sub_options) {
      newChoices[choiceIndex].sub_options = [];
    }
    newChoices[choiceIndex].sub_options.push({
      id: crypto.randomUUID(),
      name: '',
      type: 'single',
      is_required: false,
      choices: [{ id: crypto.randomUUID(), name: '', price: 0 }]
    });
    setFormData({ ...formData, choices: newChoices });
    
    // Ouvrir automatiquement le choix
    setExpandedChoices(prev => ({
      ...prev,
      [newChoices[choiceIndex].id]: true
    }));
  };

  const removeSubOption = (choiceIndex, subOptionIndex) => {
    const newChoices = [...formData.choices];
    newChoices[choiceIndex].sub_options.splice(subOptionIndex, 1);
    setFormData({ ...formData, choices: newChoices });
  };

  const updateSubOption = (choiceIndex, subOptionIndex, field, value) => {
    const newChoices = [...formData.choices];
    newChoices[choiceIndex].sub_options[subOptionIndex][field] = value;
    setFormData({ ...formData, choices: newChoices });
  };

  // ================== GESTION DES CHOIX DE SOUS-OPTIONS ==================
  const addSubOptionChoice = (choiceIndex, subOptionIndex) => {
    const newChoices = [...formData.choices];
    newChoices[choiceIndex].sub_options[subOptionIndex].choices.push({
      id: crypto.randomUUID(),
      name: '',
      price: 0
    });
    setFormData({ ...formData, choices: newChoices });
  };

  const removeSubOptionChoice = (choiceIndex, subOptionIndex, subChoiceIndex) => {
    const newChoices = [...formData.choices];
    if (newChoices[choiceIndex].sub_options[subOptionIndex].choices.length > 1) {
      newChoices[choiceIndex].sub_options[subOptionIndex].choices.splice(subChoiceIndex, 1);
      setFormData({ ...formData, choices: newChoices });
    }
  };

  const updateSubOptionChoice = (choiceIndex, subOptionIndex, subChoiceIndex, field, value) => {
    const newChoices = [...formData.choices];
    newChoices[choiceIndex].sub_options[subOptionIndex].choices[subChoiceIndex][field] = value;
    setFormData({ ...formData, choices: newChoices });
  };

  // ================== SOUMISSION ==================
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      // Nettoyer les choix vides
      const cleanedChoices = formData.choices
        .filter(c => c.name.trim())
        .map(c => ({
          ...c,
          price: parseFloat(c.price) || 0,
          sub_options: (c.sub_options || [])
            .filter(so => so.name.trim())
            .map(so => ({
              ...so,
              choices: so.choices.filter(soc => soc.name.trim()).map(soc => ({
                ...soc,
                price: parseFloat(soc.price) || 0
              }))
            }))
        }));

      const data = {
        name: formData.name,
        description: formData.description || null,
        internal_comment: formData.internal_comment || null,
        type: formData.type,
        is_required: formData.is_required,
        allow_repeat: formData.allow_repeat,
        max_choices: formData.type === 'multiple' && formData.max_choices ? parseInt(formData.max_choices) : null,
        choices: cleanedChoices,
        display_order: parseInt(formData.display_order) || 0
      };

      const url = option
        ? `${API_URL}/api/v1/admin/options/${option.id}`
        : `${API_URL}/api/v1/admin/options`;

      const response = await fetch(url, {
        method: option ? 'PUT' : 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.detail || 'Erreur lors de la sauvegarde');
      }

      showToast(option ? 'Option modifiée' : 'Option créée', 'success');
      onSuccess?.();
      onClose();
    } catch (error) {
      showToast(error.message, 'error');
    } finally {
      setLoading(false);
    }
  };

  // Compter les sous-options pour un choix
  const countSubOptions = (choice) => {
    return (choice.sub_options || []).filter(so => so.name.trim()).length;
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={option ? "Modifier l'option" : "Nouvelle option"}
      size="xl"
    >
      {/* Toast */}
      {toast && (
        <div className={`fixed top-4 right-4 z-50 px-4 py-2 rounded-lg shadow-lg ${
          toast.type === 'error' ? 'bg-red-500' : 'bg-green-500'
        } text-white`}>
          {toast.message}
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* ========== SECTION: INFOS PRINCIPALES ========== */}
        <div className="bg-gray-50 p-4 rounded-lg space-y-4">
          <h3 className="font-semibold text-gray-700">📋 Informations de l'option</h3>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Nom de l'option *</label>
            <input
              type="text"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              placeholder="Ex: Formule, Taille, Cuisson..."
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Type de sélection *</label>
              <select
                value={formData.type}
                onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500"
              >
                <option value="single">Choix unique</option>
                <option value="multiple">Choix multiples</option>
              </select>
            </div>
            
            {formData.type === 'multiple' && (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Max choix</label>
                <input
                  type="number"
                  value={formData.max_choices}
                  onChange={(e) => setFormData({ ...formData, max_choices: e.target.value })}
                  placeholder="Illimité"
                  min="1"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                />
              </div>
            )}
          </div>

          <div className="flex items-center gap-4">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={formData.is_required}
                onChange={(e) => setFormData({ ...formData, is_required: e.target.checked })}
                className="w-4 h-4 text-red-600 rounded focus:ring-red-500"
              />
              <span className="text-sm text-gray-700">Option obligatoire</span>
            </label>
          </div>
        </div>

        {/* ========== SECTION: CHOIX ========== */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-gray-700">🎯 Choix disponibles</h3>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setShowLibraryPicker({ type: 'choice' })}
                className="flex items-center gap-1 text-sm text-purple-600 hover:text-purple-700 bg-purple-50 px-3 py-1.5 rounded-lg border border-purple-200"
              >
                <BookOpen size={16} /> Depuis la bibliothèque
              </button>
              <button
                type="button"
                onClick={addChoice}
                className="flex items-center gap-1 text-sm text-red-600 hover:text-red-700"
              >
                <Plus size={16} /> Ajouter manuellement
              </button>
            </div>
          </div>

          {/* Picker de la bibliothèque */}
          {showLibraryPicker?.type === 'choice' && (
            <div className="bg-purple-50 border-2 border-purple-300 rounded-lg p-4">
              <div className="flex items-center justify-between mb-3">
                <h4 className="font-medium text-purple-800">📚 Sélectionner depuis la bibliothèque</h4>
                <button
                  type="button"
                  onClick={() => { setShowLibraryPicker(null); setLibrarySearch(''); }}
                  className="text-purple-600 hover:text-purple-800"
                >
                  <X size={18} />
                </button>
              </div>
              <input
                type="text"
                value={librarySearch}
                onChange={(e) => setLibrarySearch(e.target.value)}
                placeholder="🔍 Rechercher un choix..."
                className="w-full px-3 py-2 border border-purple-200 rounded-lg mb-3"
              />
              {filteredLibrary.length === 0 ? (
                <p className="text-sm text-purple-600 text-center py-4">
                  {choiceLibrary.length === 0 
                    ? "Aucun choix dans la bibliothèque. Créez-en dans Gestion du Menu → Bibliothèque"
                    : "Aucun résultat"
                  }
                </p>
              ) : (
                <div className="grid grid-cols-3 gap-2 max-h-48 overflow-y-auto">
                  {filteredLibrary.map(lc => (
                    <button
                      key={lc.id}
                      type="button"
                      onClick={() => addChoiceFromLibrary(lc)}
                      className="flex items-center gap-2 p-2 bg-white border border-purple-200 rounded-lg hover:bg-purple-100 transition-colors text-left"
                    >
                      {lc.image_url && (
                        <img src={lc.image_url} alt="" className="w-8 h-8 rounded object-cover" />
                      )}
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-sm truncate">{lc.name}</p>
                        <p className="text-xs text-gray-500">{lc.default_price?.toFixed(2) || '0.00'}€</p>
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}

          <div className="space-y-3">
            {formData.choices.map((choice, choiceIndex) => (
              <div key={choice.id} className="border border-gray-200 rounded-lg overflow-hidden">
                {/* En-tête du choix */}
                <div className="bg-white p-3 flex items-center gap-3">
                  <input
                    type="text"
                    value={choice.name}
                    onChange={(e) => updateChoice(choiceIndex, 'name', e.target.value)}
                    placeholder="Nom du choix"
                    className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500"
                  />
                  <div className="flex items-center gap-1">
                    <input
                      type="number"
                      value={choice.price}
                      onChange={(e) => updateChoice(choiceIndex, 'price', e.target.value)}
                      placeholder="0"
                      step="0.01"
                      className="w-20 px-2 py-2 border border-gray-300 rounded-lg text-center"
                    />
                    <span className="text-gray-500">€</span>
                  </div>
                  
                  {/* Bouton sous-options */}
                  <button
                    type="button"
                    onClick={() => toggleChoiceExpand(choice.id)}
                    className={`flex items-center gap-1 px-3 py-2 rounded-lg text-sm transition-colors ${
                      countSubOptions(choice) > 0 
                        ? 'bg-purple-100 text-purple-700 hover:bg-purple-200' 
                        : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                    }`}
                  >
                    {expandedChoices[choice.id] ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
                    <Settings size={14} />
                    {countSubOptions(choice) > 0 && (
                      <span className="bg-purple-600 text-white text-xs px-1.5 py-0.5 rounded-full">
                        {countSubOptions(choice)}
                      </span>
                    )}
                  </button>
                  
                  {formData.choices.length > 1 && (
                    <button
                      type="button"
                      onClick={() => removeChoice(choiceIndex)}
                      className="p-2 text-red-500 hover:bg-red-50 rounded-lg"
                    >
                      <Trash2 size={18} />
                    </button>
                  )}
                </div>

                {/* Section sous-options (dépliable) */}
                {expandedChoices[choice.id] && (
                  <div className="bg-purple-50 border-t border-purple-200 p-4">
                    <div className="flex items-center justify-between mb-3">
                      <p className="text-sm font-medium text-purple-800">
                        🔗 Si "{choice.name || 'ce choix'}" est sélectionné, afficher :
                      </p>
                      <button
                        type="button"
                        onClick={() => addSubOption(choiceIndex)}
                        className="flex items-center gap-1 text-sm text-purple-600 hover:text-purple-700 bg-white px-3 py-1 rounded-lg border border-purple-300"
                      >
                        <Plus size={14} /> Ajouter une sous-option
                      </button>
                    </div>

                    {(!choice.sub_options || choice.sub_options.length === 0) ? (
                      <p className="text-sm text-purple-600 italic">
                        Aucune sous-option. Cliquez sur "Ajouter une sous-option" pour en créer.
                      </p>
                    ) : (
                      <div className="space-y-4">
                        {choice.sub_options.map((subOption, subOptionIndex) => (
                          <div key={subOption.id} className="bg-white rounded-lg p-3 border border-purple-200">
                            <div className="flex items-center gap-3 mb-3">
                              <input
                                type="text"
                                value={subOption.name}
                                onChange={(e) => updateSubOption(choiceIndex, subOptionIndex, 'name', e.target.value)}
                                placeholder="Nom de la sous-option (ex: Accompagnement)"
                                className="flex-1 px-3 py-2 border border-gray-300 rounded-lg"
                              />
                              <select
                                value={subOption.type}
                                onChange={(e) => updateSubOption(choiceIndex, subOptionIndex, 'type', e.target.value)}
                                className="px-3 py-2 border border-gray-300 rounded-lg"
                              >
                                <option value="single">Choix unique</option>
                                <option value="multiple">Choix multiples</option>
                              </select>
                              <label className="flex items-center gap-1 text-sm whitespace-nowrap">
                                <input
                                  type="checkbox"
                                  checked={subOption.is_required}
                                  onChange={(e) => updateSubOption(choiceIndex, subOptionIndex, 'is_required', e.target.checked)}
                                  className="w-4 h-4 text-purple-600 rounded"
                                />
                                Obligatoire
                              </label>
                              <button
                                type="button"
                                onClick={() => removeSubOption(choiceIndex, subOptionIndex)}
                                className="p-2 text-red-500 hover:bg-red-50 rounded-lg"
                              >
                                <Trash2 size={16} />
                              </button>
                            </div>

                            {/* Choix de la sous-option */}
                            <div className="pl-4 border-l-2 border-purple-200 space-y-2">
                              <div className="flex items-center justify-between mb-2">
                                <p className="text-xs text-gray-500">Choix disponibles :</p>
                                <button
                                  type="button"
                                  onClick={() => setShowLibraryPicker({ type: 'subChoice', choiceIndex, subOptionIndex })}
                                  className="text-xs text-purple-600 hover:text-purple-700 flex items-center gap-1 bg-purple-50 px-2 py-1 rounded border border-purple-200"
                                >
                                  <BookOpen size={12} /> Bibliothèque
                                </button>
                              </div>
                              
                              {/* Picker bibliothèque pour sous-choix */}
                              {showLibraryPicker?.type === 'subChoice' && 
                               showLibraryPicker.choiceIndex === choiceIndex && 
                               showLibraryPicker.subOptionIndex === subOptionIndex && (
                                <div className="bg-white border border-purple-300 rounded-lg p-3 mb-2">
                                  <input
                                    type="text"
                                    value={librarySearch}
                                    onChange={(e) => setLibrarySearch(e.target.value)}
                                    placeholder="🔍 Rechercher..."
                                    className="w-full px-2 py-1 border border-purple-200 rounded text-sm mb-2"
                                  />
                                  <div className="grid grid-cols-2 gap-1 max-h-32 overflow-y-auto">
                                    {filteredLibrary.map(lc => (
                                      <button
                                        key={lc.id}
                                        type="button"
                                        onClick={() => addSubChoiceFromLibrary(lc, choiceIndex, subOptionIndex)}
                                        className="text-xs p-1.5 bg-purple-50 border border-purple-200 rounded hover:bg-purple-100 text-left truncate"
                                      >
                                        {lc.name} ({lc.default_price?.toFixed(2) || '0'}€)
                                      </button>
                                    ))}
                                  </div>
                                  {filteredLibrary.length === 0 && (
                                    <p className="text-xs text-gray-400 text-center py-2">Aucun choix trouvé</p>
                                  )}
                                </div>
                              )}
                              
                              {subOption.choices.map((subChoice, subChoiceIndex) => (
                                <div key={subChoice.id} className="flex items-center gap-2">
                                  <input
                                    type="text"
                                    value={subChoice.name}
                                    onChange={(e) => updateSubOptionChoice(choiceIndex, subOptionIndex, subChoiceIndex, 'name', e.target.value)}
                                    placeholder="Nom du choix"
                                    className="flex-1 px-2 py-1 border border-gray-300 rounded text-sm"
                                  />
                                  <div className="flex items-center gap-1">
                                    <input
                                      type="number"
                                      value={subChoice.price}
                                      onChange={(e) => updateSubOptionChoice(choiceIndex, subOptionIndex, subChoiceIndex, 'price', e.target.value)}
                                      placeholder="0"
                                      step="0.01"
                                      className="w-16 px-2 py-1 border border-gray-300 rounded text-sm text-center"
                                    />
                                    <span className="text-gray-400 text-sm">€</span>
                                  </div>
                                  {subOption.choices.length > 1 && (
                                    <button
                                      type="button"
                                      onClick={() => removeSubOptionChoice(choiceIndex, subOptionIndex, subChoiceIndex)}
                                      className="p-1 text-red-400 hover:text-red-600"
                                    >
                                      <X size={14} />
                                    </button>
                                  )}
                                </div>
                              ))}
                              <button
                                type="button"
                                onClick={() => addSubOptionChoice(choiceIndex, subOptionIndex)}
                                className="text-xs text-purple-600 hover:text-purple-700 flex items-center gap-1 mt-1"
                              >
                                <Plus size={12} /> Ajouter manuellement
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* ========== SECTION: COMMENTAIRE INTERNE ========== */}
        <div className="bg-amber-50 p-4 rounded-lg">
          <label className="block text-sm font-medium text-amber-800 mb-2">
            💬 Commentaire interne (non visible par le client)
          </label>
          <textarea
            value={formData.internal_comment}
            onChange={(e) => setFormData({ ...formData, internal_comment: e.target.value })}
            placeholder="Notes internes, instructions pour le personnel..."
            rows={2}
            className="w-full px-3 py-2 border border-amber-200 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white"
          />
        </div>

        {/* ========== BOUTONS ========== */}
        <div className="flex justify-end gap-3 pt-4 border-t">
          <button
            type="button"
            onClick={onClose}
            className="px-6 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
          >
            Annuler
          </button>
          <button
            type="submit"
            disabled={loading || !formData.name.trim()}
            className="px-6 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 disabled:opacity-50"
          >
            {loading ? 'Enregistrement...' : (option ? 'Mettre à jour' : 'Créer')}
          </button>
        </div>
      </form>
    </Modal>
  );
};

export default OptionModal;
