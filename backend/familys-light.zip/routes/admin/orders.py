from fastapi import APIRouter, HTTPException, Security, status, Query
from typing import List, Optional
from models.order import Order, OrderStatusUpdate, OrderStatus
from middleware.auth import require_manager_or_admin
from datetime import datetime, timezone

from database import db
from services.notification_service import send_order_notification

router = APIRouter(prefix="/orders", tags=["admin-orders"])

from pydantic import BaseModel

class PaymentUpdate(BaseModel):
    payment_method: str
    payment_status: str
    amount_received: Optional[float] = None
    change_given: Optional[float] = None


@router.get("")  # response_model=List[Order]  # TEMPORAIREMENT SANS VALIDATION
async def get_orders(
    status: Optional[str] = None,
    date_from: Optional[str] = None,
    date_to: Optional[str] = None,
    payment_method: Optional[str] = None,
    limit: int = Query(100, le=500),
    skip: int = 0
    # current_user: dict = Security(require_manager_or_admin)  # TEMPORAIREMENT DESACTIVE
):
    """Get orders with filters."""
    restaurant_id = "default"  # current_user.get("restaurant_id")
    
    query = {"restaurant_id": restaurant_id}
    
    if status:
        query["status"] = status
    
    if payment_method:
        query["payment_method"] = payment_method
    
    if date_from and date_to:
        query["created_at"] = {
            "$gte": date_from,
            "$lte": date_to
        }
    
    orders = await db.orders.find(query, {"_id": 0}).sort("created_at", -1).skip(skip).limit(limit).to_list(length=None)
    
    return {"orders": orders}

@router.get("/{order_id}", response_model=Order)
async def get_order(
    order_id: str,
    current_user: dict = Security(require_manager_or_admin)
):
    """Get single order."""
    restaurant_id = current_user.get("restaurant_id")
    
    order = await db.orders.find_one({
        "id": order_id,
        "restaurant_id": restaurant_id
    })
    
    if not order:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Order not found"
        )
    
    return Order(**order)

@router.patch("/{order_id}/status")  # response_model=Order  # TEMPORAIREMENT SANS VALIDATION
async def update_order_status(
    order_id: str,
    status_update: OrderStatusUpdate
    # current_user: dict = Security(require_manager_or_admin)  # TEMPORAIREMENT DESACTIVE
):
    """Update order status with validation rules."""
    restaurant_id = "default"  # current_user.get("restaurant_id")
    
    # Check if order exists
    existing = await db.orders.find_one({
        "id": order_id,
        "restaurant_id": restaurant_id
    })
    
    if not existing:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Order not found"
        )
    
    current_status = existing.get("status")
    new_status = status_update.status
    order_type = existing.get("order_type", "takeaway")
    payment_status = existing.get("payment_status", "pending")
    
    # ===== VALIDATION DES TRANSITIONS DE STATUTS =====
    
    # Définir les transitions valides
    valid_transitions = {
        "new": ["in_preparation", "canceled"],
        "in_preparation": ["ready", "canceled"],
        "ready": ["out_for_delivery", "completed", "canceled"] if order_type == "delivery" else ["completed", "canceled"],
        "out_for_delivery": ["completed", "canceled"],
        "completed": [],  # État final
        "canceled": []    # État final
    }
    
    # Vérifier que le statut est valide
    valid_statuses = ["new", "in_preparation", "ready", "out_for_delivery", "completed", "canceled"]
    if new_status not in valid_statuses:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Statut invalide: {new_status}. Statuts valides: {', '.join(valid_statuses)}"
        )
    
    # Vérifier que la transition est autorisée
    if new_status not in valid_transitions.get(current_status, []):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Transition non autorisée: {current_status} → {new_status}. Transitions possibles depuis {current_status}: {', '.join(valid_transitions.get(current_status, []))}"
        )
    
    # ===== VALIDATION DU PAIEMENT POUR COMPLÉTION =====
    
    # Bloquer la complétion si la commande n'est pas payée
    if new_status == "completed" and payment_status != "paid":
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="❌ PAIEMENT REQUIS: Cette commande ne peut pas être terminée car elle n'est pas encore payée. Veuillez d'abord enregistrer le paiement."
        )
    
    # Update status
    update_data = {
        "status": new_status,
        "updated_at": datetime.now(timezone.utc).isoformat()
    }
    
    # Add cancellation reason if provided
    if status_update.cancellation_reason:
        update_data["cancellation_reason"] = status_update.cancellation_reason
    
    await db.orders.update_one(
        {"id": order_id},
        {"$set": update_data}
    )
    
    # Envoyer notification selon le statut
    notification_map = {
        "in_preparation": "order_preparing",
        "ready": "order_ready",
        "out_for_delivery": "order_delivering",
        "completed": "order_completed"
    }
    
    if status_update.status in notification_map:
        await send_order_notification(
            order_id=order_id,
            notification_type=notification_map[status_update.status],
            restaurant_id=restaurant_id
        )
    
    # Get updated order
    updated_order = await db.orders.find_one({"id": order_id}, {"_id": 0})
    return {"success": True, "order": updated_order}

@router.post("/{order_id}/payment")
async def update_order_payment(
    order_id: str,
    payment_update: PaymentUpdate
    # current_user: dict = Security(require_manager_or_admin)  # TEMPORAIREMENT DESACTIVE
):
    """Update order payment status and method."""
    restaurant_id = "default"  # current_user.get("restaurant_id")
    
    # Check if order exists
    existing = await db.orders.find_one({
        "id": order_id,
        "restaurant_id": restaurant_id
    })
    
    if not existing:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Order not found"
        )
    
    # Update payment
    update_data = {
        "payment_method": payment_update.payment_method,
        "payment_status": payment_update.payment_status,
        "updated_at": datetime.now(timezone.utc).isoformat()
    }
    
    # Add amount_received and change_given if provided
    if payment_update.amount_received is not None:
        update_data["amount_received"] = payment_update.amount_received
    if payment_update.change_given is not None:
        update_data["change_given"] = payment_update.change_given
    
    await db.orders.update_one(
        {"id": order_id},
        {"$set": update_data}
    )
    
    # Si le paiement est confirmé (paid) et que la commande est terminée, créditer le cashback
    if payment_update.payment_status == "paid" and existing.get("status") == "completed":
        # Utiliser le cashback_earned de la commande si disponible, sinon recalculer
        cashback_earned = existing.get("cashback_earned")
        
        if cashback_earned is None or cashback_earned == 0:
            # Recalculer si pas présent (commandes anciennes)
            from services.cashback_service import calculate_cashback_earned
            cashback_earned = await calculate_cashback_earned(
                subtotal=existing.get("subtotal", 0),
                total_after_promos=existing.get("total", 0)
            )
        
        # Récupérer le client
        customer_email = existing.get("customer_email")
        customer_phone = existing.get("customer_phone")
        
        if customer_email or customer_phone:
            # Chercher le client
            customer_query = {}
            if customer_email:
                customer_query["email"] = customer_email
            elif customer_phone:
                customer_query["phone"] = customer_phone
            
            customer = await db.customers.find_one(customer_query)
            
            if customer:
                # Créditer le cashback
                from services.cashback_service import add_cashback_to_customer
                result = await add_cashback_to_customer(
                    customer_id=customer.get("id"),
                    amount=cashback_earned
                )
                
                new_loyalty_points = result["new_balance"]
                
                # Envoyer la notification
                from routes.notifications import send_loyalty_credited_notification
                await send_loyalty_credited_notification(
                    user_id=customer.get("id"),
                    order_id=order_id,
                    amount_credited=cashback_earned,
                    total_points=new_loyalty_points
                )
    
    return {"success": True, "message": "Payment updated successfully"}

@router.get("/stats/summary")
async def get_orders_summary(current_user: dict = Security(require_manager_or_admin)):
    """Get orders summary statistics."""
    restaurant_id = current_user.get("restaurant_id")
    
    # Count by status
    pipeline = [
        {"$match": {"restaurant_id": restaurant_id}},
        {"$group": {
            "_id": "$status",
            "count": {"$sum": 1},
            "total_revenue": {"$sum": "$total"}
        }}
    ]
    
    result = await db.orders.aggregate(pipeline).to_list(length=None)
    
    return {
        "by_status": [
            {"status": item["_id"], "count": item["count"], "revenue": item["total_revenue"]}
            for item in result
        ]
    }
