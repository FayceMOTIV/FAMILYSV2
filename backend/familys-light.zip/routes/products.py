"""
Routes publiques pour les produits
"""
from fastapi import APIRouter, HTTPException, Query
from database import db
from typing import Optional, List

router = APIRouter()

@router.get("/products")
async def get_products(
    category: Optional[str] = None,
    search: Optional[str] = None,
    skip: int = Query(0, ge=0),
    limit: int = Query(50, ge=1, le=100)
):
    """
    Récupérer les produits avec filtres optionnels
    """
    try:
        query = {"is_available": True}
        
        # Filtre par catégorie
        if category:
            query["category"] = category
        
        # Recherche par nom ou description
        if search:
            query["$or"] = [
                {"name": {"$regex": search, "$options": "i"}},
                {"description": {"$regex": search, "$options": "i"}}
            ]
        
        products = await db.products.find(
            query,
            {"_id": 0}
        ).skip(skip).limit(limit).to_list(length=limit)
        
        return {"products": products}
    except Exception as e:
        print(f"Error getting products: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/products/{product_id}")
async def get_product(product_id: str):
    """
    Récupérer un produit par ID
    """
    try:
        product = await db.products.find_one(
            {"id": product_id},
            {"_id": 0}
        )
        
        if not product:
            raise HTTPException(status_code=404, detail="Produit non trouvé")
        
        return product
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error getting product: {e}")
        raise HTTPException(status_code=500, detail=str(e))
